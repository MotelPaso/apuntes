# Fundamentos de la Computación   

### Unidades:   
[[ teoria-de-conjuntos | Teoria de Conjuntos ]]    
[[funciones| Funciones ]]    
[[ fundamentos-de-logica | Fundamentos de Logica ]]
[[lenguajes|Lenguajes]]
[[automatas-finitos]]
[[automatas-no-finitos]]

### Pruebas:   
[[ pp1 | PP1 ]]    
   













